# Sims IRL

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://github.com/Valerieclaire96/sims-rooms-irl.git)

![Alt Text](https://media.giphy.com/media/leog6GiMgvAEPisrDZ/giphy-downsized.gif)

<p align="center">
<a href="https://imgur.com/Dex7E9o"><img src="https://i.imgur.com/Dex7E9o.gif" title="source: imgur.com" /></a>

A website that connects users with for-sale items that resemble those in The Sims 4.
Created with Python, SQL Alchemy, Flask, Fetch, React, Bootstrap, CSS, and Algolia API.
