You can find a comprehensive documentation about this boilerplate here:
https://start.4geeksacademy.com/starters/full-stack