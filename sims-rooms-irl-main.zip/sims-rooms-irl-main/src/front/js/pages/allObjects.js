import React from 'react'
import Search from '../component/search'

export default function AllObjects() {
  return (
    <div className='container'>
      <Search />
      </div>
  )
}
